# RZigZag 0.1

* This is the first version, which introduces the R functions `ZigZagLogistic` and `ZigZagGaussian`.
