# Comments concerning RZigZag

* RCppEigen leads to a file size > 10 MB on my pc, unless compiled with CXXFLAGS=-O3. However this does not seem to be the case in the release check
